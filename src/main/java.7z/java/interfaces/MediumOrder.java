package interfaces;

public interface MediumOrder {
}
