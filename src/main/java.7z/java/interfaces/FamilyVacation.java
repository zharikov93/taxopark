package interfaces;


public interface FamilyVacation {
}
