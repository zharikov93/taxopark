package interfaces;

public interface SmallOrder {
}
