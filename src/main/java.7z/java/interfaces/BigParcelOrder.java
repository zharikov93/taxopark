package interfaces;

public interface BigParcelOrder {
}
