package interfaces;

public interface BigPassengerOrder {
}
