package autopark.family;

import autopark.Car;
import interfaces.FamilyVacation;
import interfaces.SmallOrder;



public abstract class FamilyCar extends Car implements SmallOrder, FamilyVacation {

}
