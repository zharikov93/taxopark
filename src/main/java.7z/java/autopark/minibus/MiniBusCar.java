package autopark.minibus;

import autopark.Car;

public abstract class MiniBusCar extends Car {
    public  MiniBusCar() {
        doors = 4;
    }
}
